public interface InterfaceChannelTV {
    public void gantiChannel(int c);
}